( cd etc ; ln -s ../proc/mounts mtab )
