( cd / ; ln -s /usr/bin )
( cd / ; ln -s /usr/sbin )
( cd /etc ; ln -s ../proc/mounts mtab )
