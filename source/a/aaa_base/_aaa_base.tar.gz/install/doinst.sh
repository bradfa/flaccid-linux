( ln -s usr/bin )
( ln -s usr/sbin )
( cd etc ; ln -s ../proc/mounts mtab )
